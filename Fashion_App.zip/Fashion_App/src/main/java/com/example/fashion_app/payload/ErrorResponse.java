package com.example.fashion_app.payload;

public class ErrorResponse {
}
