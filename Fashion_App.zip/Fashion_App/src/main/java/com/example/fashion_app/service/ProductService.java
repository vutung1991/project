package com.example.fashion_app.service;

import com.example.fashion_app.entity.Product;

import java.util.List;

public interface ProductService {

    List<Product> getAllProducts();

    Product getProductById(Long id);

    void createProduct(Product product);
    void updateProduct(Long id, Product product);
    void deleteProduct(Long id);

}
